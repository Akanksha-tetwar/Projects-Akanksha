/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.Role;
import Business.Role.TechSupportEmployeeRole;
import Business.Role.TechnicianRole;
import java.util.ArrayList;

/**
 *
 * @author Akanksha
 */
public class SupportEnterprise extends Enterprise{

    public SupportEnterprise(String name) {
        super(name, Enterprise.EnterpriseType.Support);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new TechnicianRole());
        roles.add(new TechSupportEmployeeRole());
        return roles; //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
}
