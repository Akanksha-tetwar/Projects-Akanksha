/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author staka
 */
public abstract class Enterprise extends Organization{
    private EnterpriseType enterprisetype;
    private Organization organization;
    private OrganizationDirectory organizationdirectory;
    
    public OrganizationDirectory getOrganizationdirectory() {
        return organizationdirectory;
    }
    
    public enum EnterpriseType {
        Advisory("Advisory"),
        Content("Content"),
        Product("Product"),
        Support("Support");

        private String value;

        private EnterpriseType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
        
    }
    
    

    public EnterpriseType getEnterprisetype() {
        return enterprisetype;
    }

    public void setEnterprisetype(EnterpriseType enterprisetype) {
        this.enterprisetype = enterprisetype;
    }
    
    
    public Enterprise(String name,EnterpriseType type) {
        super(name);
        this.enterprisetype = type;
        organizationdirectory = new OrganizationDirectory();
    }
    
    
    
}
