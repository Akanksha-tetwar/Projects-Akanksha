/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.BloggerEmployeeRole;
import Business.Role.BloggerRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Akanksha
 */
public class ContentEnterprise extends Enterprise{
    
    public ContentEnterprise(String name) {
        super(name, Enterprise.EnterpriseType.Content);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new BloggerRole());
        roles.add(new BloggerEmployeeRole());
        return roles;//To change body of generated methods, choose Tools | Templates.
    }

    
  
    
}
