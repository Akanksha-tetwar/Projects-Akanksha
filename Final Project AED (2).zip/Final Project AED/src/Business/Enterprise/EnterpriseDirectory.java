/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import java.util.ArrayList;

/**
 *
 * @author staka
 */
public class EnterpriseDirectory {
    private ArrayList<Enterprise> enterpriselist;

    public ArrayList<Enterprise> getEnterpriselist() {
        return enterpriselist;
    }

    public void setEnterpriselist(ArrayList<Enterprise> enterpriselist) {
        this.enterpriselist = enterpriselist;
    }
    
    public EnterpriseDirectory(){
    enterpriselist = new ArrayList<Enterprise>();
    }
    
    public Enterprise createAndAddEnterprise(String name, Enterprise.EnterpriseType type){
        Enterprise enterprise=null;
        if (null != type) {
            switch (type) {
                case Advisory:
                    enterprise = new AdvisoryEnterprise(name);
                    enterpriselist.add(enterprise);
                    break;
                case Support:
                    enterprise = new SupportEnterprise(name);
                    enterpriselist.add(enterprise);
                    break;
                case Product:
                    enterprise = new ProductEnterprise(name);
                    enterpriselist.add(enterprise);
                    break;
                case Content:
                    enterprise = new ContentEnterprise(name);
                    enterpriselist.add(enterprise);
                    break;
                default:
                    break;
            }
            }
        return enterprise;
    }
        
}
