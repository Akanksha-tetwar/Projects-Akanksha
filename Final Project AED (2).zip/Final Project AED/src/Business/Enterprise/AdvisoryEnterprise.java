/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.AdvisingManagerRole;
import Business.Role.Dietician;
import Business.Role.GymAdvisor;
import Business.Role.MentalHealthAdvisor;
import Business.Role.Physiotherapist;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Akanksha 
 */
public  class AdvisoryEnterprise extends Enterprise{

    public AdvisoryEnterprise(String name) {
        super(name, EnterpriseType.Advisory);
    }
    
    

    @Override
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new AdvisingManagerRole());
        roles.add(new Dietician());
        roles.add(new GymAdvisor());
        roles.add(new MentalHealthAdvisor());
        roles.add(new Physiotherapist());
        return roles;//To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
    
    
}
