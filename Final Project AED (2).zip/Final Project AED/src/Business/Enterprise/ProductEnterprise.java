/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.DeliveryManRole;
import Business.Role.ProductManagerRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author staka
 */
public class ProductEnterprise extends Enterprise{
    
     public ProductEnterprise(String name) {
        super(name, Enterprise.EnterpriseType.Product);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new DeliveryManRole());
        roles.add(new ProductManagerRole());
        return roles; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
