/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AdvisoryServices;

import java.util.ArrayList;

/**
 *
 * @author shrvs
 */
public class AdvisoryServicesDirectory {

    private ArrayList<AdvisoryServices> advisoryservicesList = new ArrayList<AdvisoryServices>();

    public ArrayList<AdvisoryServices> getAdvisoryservicesList() {
        return advisoryservicesList;
    }

    public void setAdvisoryservicesList(ArrayList<AdvisoryServices> advisoryservicesList) {
        this.advisoryservicesList = advisoryservicesList;
    }

    

    public String generatePropertyID() {
        return "Service" + (advisoryservicesList.size() + 1);
    }

    public AdvisoryServices fetchService(String ServiceNo) {
        for (AdvisoryServices advisoryservices : advisoryservicesList) {
            if (advisoryservices.getServiceID().equalsIgnoreCase(ServiceNo)) {
                return advisoryservices;
            }
        }
        return null;
    }

    public AdvisoryServices searchServiceName(String ServiceName) {
        for (AdvisoryServices advisoryservices : advisoryservicesList) {
            if (advisoryservices.getServiceName().equalsIgnoreCase(ServiceName)) {
                return advisoryservices;
            }
        }
        return null;
    }

    ///./////// need to change ///////////////
    public AdvisoryServices getServiceByIndex(int index) {
        return advisoryservicesList.get(index);
    }

    public void addService(AdvisoryServices advisoryservices) {
        advisoryservicesList.add(advisoryservices);
    }

    public void removeService(AdvisoryServices advisoryservices) {
        advisoryservicesList.remove(advisoryservices);
    }

}
