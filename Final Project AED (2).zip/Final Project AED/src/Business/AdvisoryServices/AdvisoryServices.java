/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.AdvisoryServices;

import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author shrvs
 */
public class AdvisoryServices {
    
     private String uploadImg;
     private String serviceID;
     private String serviceName;
     private String Address;
     private String City;
     private String State;
     private String Zipcode;
     private String Status;
     private double Price;
     private UserAccount member;
     private double latitude;
     private double longitude;
     
    ArrayList<ImageIcon> images = new ArrayList<>();
    ArrayList<UserAccount> RegisteredMember = new ArrayList<UserAccount>();

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    
    public String getUploadImg() {
        return uploadImg;
    }

    public void setUploadImg(String uploadImg) {
        this.uploadImg = uploadImg;
    }

    public String getServiceID() {
        return serviceID;
    }

    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String memberName) {
        this.serviceName = serviceName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getZipcode() {
        return Zipcode;
    }

    public void setZipcode(String Zipcode) {
        this.Zipcode = Zipcode;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public UserAccount getMember() {
        return member;
    }

    public void setMember(UserAccount member) {
        this.member = member;
    }

    

    public ArrayList<ImageIcon> getImages() {
        return images;
    }

    public void setImages(ArrayList<ImageIcon> images) {
        this.images = images;
    }

    public ArrayList<UserAccount> getRegisteredMember() {
        return RegisteredMember;
    }

    public void setRegisteredMember(ArrayList<UserAccount> RegisteredMember) {
        this.RegisteredMember = RegisteredMember;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }
    
    
}
