/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;


import Business.Role.BloggerEmployeeRole;
import Business.Role.BloggerRole;
import Business.Role.Role;
import static Business.Role.Role.RoleType.Blogger;
import java.util.ArrayList;

/**
 *
 * @author Akanksha
 * 
 */
public class BloggingOrganization extends Organization{

    public BloggingOrganization(String name) {
        super(name);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new BloggerEmployeeRole());
        return roles;
    }
    
    @Override
    public Type getType() {
        return Organization.Type.Blogging;
    } 
}
