/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author Akanksha
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationlist;

    public OrganizationDirectory() {
        organizationlist = new ArrayList();
        
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationlist;
    }
    
    public Organization createOrganization(Organization.Type type, String name) {
        Organization organization = null;
        if (type.getValue().equals(Type.Yoga.getValue())) {
            organization = new YogaOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.Gym.getValue())) {
            organization = new GymOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.Physiotherapy.getValue())) {
            organization = new PhysiotherapyOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.DietAdvisory.getValue())) {
            organization = new DietAdvisoryOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.Delivery.getValue())) {
            organization = new DeliveryOrganization(name);
            //organization.add(organization);
        } else if (type.getValue().equals(Type.Blogging.getValue())) {
            organization = new BloggingOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.TechSupport.getValue())) {
            organization = new TechSupportOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.MentalHealth.getValue())) {
            organization = new MentalHealthOrganization(name);
            organizationlist.add(organization);
        } else if (type.getValue().equals(Type.Member.getValue())) {
            organization = new MemberOrganization(name);
            organizationlist.add(organization);
        } 
        
        return organization;
    }

}
