/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;
import userinterface.MemberRole.MemberScreenJPanel;

/**
 *
 * @author Akanksha 
 */
public class MemberRole extends Role{
    @Override
    public String toString(){
        return (Role.RoleType.Member.getValue());
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, Network network, EcoSystem business) {
        return new MemberScreenJPanel(userProcessContainer, business, account, enterprise, network, organization); //To change body of generated methods, choose Tools | Templates.
    }
    
}
