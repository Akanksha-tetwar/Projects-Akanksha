/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.AdvisoryServices.AdvisoryServices;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author shrvs
 */
public class PhysiotherapistRequest extends WorkRequest{
    ArrayList<String> advisoryServicesList = new ArrayList<String>();
    private Network network;
    private Enterprise enterprise;
    private Organization.Type orgType;
    private String requestID;
    private UserAccount member;
    private UserAccount physiotherapist;
    private AdvisoryServices advisoryServices;
    private String memberComment;
    private String status;
    private String requestedDate;
    private String physiotherapistMessage;
    int min = 100;
    int max = 999;
    
public PhysiotherapistRequest() {
    //        int randomNum = (int) (Math.random() * (max - min + 1) + min);
//        requestID = "Request" + randomNum;
    
}

    public ArrayList<String> getAdvisoryServicesList() {
        return advisoryServicesList;
    }

    public void setAdvisoryServicesList(ArrayList<String> advisoryServicesList) {
        this.advisoryServicesList = advisoryServicesList;
    }

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }

    public Enterprise getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(Enterprise enterprise) {
        this.enterprise = enterprise;
    }

    public Organization.Type getOrgType() {
        return orgType;
    }

    public void setOrgType(Organization.Type orgType) {
        this.orgType = orgType;
    }

       public String getRequestID() {
        return requestID;
    }

    public void setRequestID() {
        int randomNum = (int) (Math.random() * (max - min + 1) + min);
        this.requestID = "Request" + randomNum;
    }

    public UserAccount getPhysiotherapist() {
        return physiotherapist;
    }

    public void setPhysiotherapist(UserAccount physiotherapist) {
        this.physiotherapist = physiotherapist;
    }

    

    

    public UserAccount getMember() {
        return member;
    }

    public void setMember(UserAccount member) {
        this.member = member;
    }

    public AdvisoryServices getAdvisoryServices() {
        return advisoryServices;
    }

    public void setAdvisoryServices(AdvisoryServices advisoryServices) {
        this.advisoryServices = advisoryServices;
    }

    public String getMemberComment() {
        return memberComment;
    }

    public void setMemberComment(String memberComment) {
        this.memberComment = memberComment;
    }

    public String getPhysiotherapistMessage() {
        return physiotherapistMessage;
    }

    public void setPhysiotherapistMessage(String physiotherapistMessage) {
        this.physiotherapistMessage = physiotherapistMessage;
    }

    
    

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(String requestedDate) {
        this.requestedDate = requestedDate;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

}
